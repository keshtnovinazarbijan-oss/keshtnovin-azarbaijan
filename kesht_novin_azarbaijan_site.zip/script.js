
// Language toggle and form behavior
const btnFA = document.getElementById('lang-fa');
const btnEN = document.getElementById('lang-en');
const htmlRoot = document.getElementById('htmlRoot');
let currentLang = 'fa';

function setLanguage(lang){
  currentLang = lang;
  // toggle active buttons
  btnFA.classList.toggle('active', lang === 'fa');
  btnEN.classList.toggle('active', lang === 'en');

  // show/hide elements with data-lang attributes
  document.querySelectorAll('[data-lang]').forEach(el=>{
    if(el.getAttribute('data-lang') === lang){
      el.classList.remove('hidden');
    } else {
      el.classList.add('hidden');
    }
  });

  // direction
  if(lang === 'fa'){
    document.documentElement.lang = 'fa';
    document.documentElement.classList.add('rtl');
    document.documentElement.dir = 'rtl';
  } else {
    document.documentElement.lang = 'en';
    document.documentElement.classList.remove('rtl');
    document.documentElement.dir = 'ltr';
  }

  // update order buttons label when language changes
  document.querySelectorAll('.order-btn').forEach(b=>{
    const fa = b.getAttribute('data-langlabelfa') || 'درخواست';
    const en = b.getAttribute('data-langlabelen') || 'Order';
    b.textContent = (lang === 'fa') ? fa : en;
  });

  // update submit button label
  const submitBtn = document.getElementById('submitBtn');
  if(submitBtn){
    submitBtn.textContent = (lang === 'fa') ? 'ارسال سفارش' : 'Send Order';
  }
}

btnFA.addEventListener('click', ()=>setLanguage('fa'));
btnEN.addEventListener('click', ()=>setLanguage('en'));

// Initialize
setLanguage('fa');

// When user clicks "Order" on a product, populate the product field and scroll to form
document.querySelectorAll('.order-btn').forEach(b=>{
  b.addEventListener('click', (e)=>{
    const productName = e.currentTarget.getAttribute('data-product') || '';
    document.getElementById('product').value = productName;
    // switch language? keep current
    document.getElementById('name').focus();
    // smooth scroll to contact form
    document.getElementById('contact').scrollIntoView({behavior:'smooth'});
  });
});

// Prepare mailto link and open default mail client with filled content
function prepareMail(e){
  e.preventDefault();
  const name = encodeURIComponent(document.getElementById('name').value || '');
  const phone = encodeURIComponent(document.getElementById('phone').value || '');
  const product = encodeURIComponent(document.getElementById('product').value || '');
  const notes = encodeURIComponent(document.getElementById('notes').value || '');

  const subject = encodeURIComponent((currentLang === 'fa') ? 'سفارش محصول - کشت نوین آذربایجان' : 'Product Order - Kesht Novin Azarbaijan');

  const bodyLines = [
    (currentLang === 'fa') ? ('نام: ' + decodeURIComponent(name)) : ('Name: ' + decodeURIComponent(name)),
    (currentLang === 'fa') ? ('تلفن: ' + decodeURIComponent(phone)) : ('Phone: ' + decodeURIComponent(phone)),
    (currentLang === 'fa') ? ('محصول: ' + decodeURIComponent(product)) : ('Product: ' + decodeURIComponent(product)),
    (currentLang === 'fa') ? ('توضیحات: ' + decodeURIComponent(notes)) : ('Notes: ' + decodeURIComponent(notes)),
  ];
  const body = encodeURIComponent(bodyLines.join('\n'));

  const mail = 'keshtnovinazarbijan@gmail.com';
  const mailto = `mailto:${mail}?subject=${subject}&body=${body}`;
  // open mail client
  window.location.href = mailto;
  return false;
}
